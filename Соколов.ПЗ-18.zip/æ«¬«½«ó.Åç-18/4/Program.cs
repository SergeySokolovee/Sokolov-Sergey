﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите число (unsigned long): ");
        string input = Console.ReadLine();

        ulong number;

        if (ulong.TryParse(input, out number))
        {
            string hexRepresentation = number.ToString("X"); 

            Console.WriteLine($"Шестнадцатеричное представление числа {number} равно: {hexRepresentation}");
        }
        else
        {
            Console.WriteLine("Некорректный ввод. Пожалуйста, введите допустимое число.");
        }
    }
}

