﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите N: ");
        int N = Convert.ToInt32(Console.ReadLine());

        double sumUsingLoop = CalculateSumUsingLoop(N);
        Console.WriteLine($"Сумма ряда через цикл: {sumUsingLoop}");

        double sumUsingFormula = CalculateSumUsingFormula(N);
        Console.WriteLine($"Сумма ряда через формулу: {sumUsingFormula}");

        if (Math.Abs(sumUsingLoop - sumUsingFormula) < 0.0001)
        {
            Console.WriteLine("Результаты совпадают.");
        }
        else
        {
            Console.WriteLine("Результаты не совпадают.");
        }

        Console.WriteLine("При больших N сумма стремится к 2.");
    }

    static double CalculateSumUsingLoop(int N)
    {
        double sum = 0.0;

        for (int i = 0; i <= N; i++)
        {
            sum += 1.0 / Math.Pow(2, i); 
        }

        return sum;
    }

    static double CalculateSumUsingFormula(int N)
    {
        double a = 1;
        double r = 0.5; 

        return a * (1 - Math.Pow(r, N + 1)) / (1 - r); 
    }
}

