﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите радиус сферы: ");
        double radius = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите количество итераций: ");
        int iterations = Convert.ToInt32(Console.ReadLine());

        double estimatedVolume = EstimateSphereVolume(radius, iterations);

        double exactVolume = (4 / 3.0) * Math.PI * Math.Pow(radius, 3);

        double accuracy = Math.Abs(estimatedVolume - exactVolume) / exactVolume * 100;

        Console.WriteLine($"Оцененный объем сферы: {estimatedVolume}");
        Console.WriteLine($"Точный объем сферы: {exactVolume}");
        Console.WriteLine($"Точность: {accuracy}%");
    }

    static double EstimateSphereVolume(double radius, int iterations)
    {
        Random random = new Random();
        int insideCount = 0;

        for (int i = 0; i < iterations; i++)
        {
            double x = (random.NextDouble() * 2 - 1) * radius;
            double y = (random.NextDouble() * 2 - 1) * radius;
            double z = (random.NextDouble() * 2 - 1) * radius;

            if (x * x + y * y + z * z <= radius * radius)
            {
                insideCount++;
            }
        }

        double cubeVolume = Math.Pow(radius * 2, 3);

        return (insideCount / (double)iterations) * cubeVolume;
    }
}
