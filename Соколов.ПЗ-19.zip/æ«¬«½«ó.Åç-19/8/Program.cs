﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите значение x (в радианах): ");
        double x = Convert.ToDouble(Console.ReadLine());

        int terms = 20; 

        double tanApproximation = CalculateTangent(x, terms);
        Console.WriteLine($"Приближенное значение tg({x}) через разложение в ряд: {tanApproximation}");

        double tanLibrary = Math.Tan(x);
        Console.WriteLine($"Значение tg({x}) через Math.Tan: {tanLibrary}");

        Console.WriteLine($"Разница: {Math.Abs(tanApproximation - tanLibrary)}");
    }

    static double CalculateTangent(double x, int terms)
    {
        double sinX = CalculateSine(x, terms);
        double cosX = CalculateCosine(x, terms);

        if (Math.Abs(cosX) < 0.00001) 
        {
            throw new DivideByZeroException("Косинус слишком близок к нулю, тангенс не определен.");
        }

        return sinX / cosX;
    }
    static double CalculateSine(double x, int terms)
    {
        double result = 0.0;

        for (int n = 0; n < terms; n++)
        {
            result += (Math.Pow(-1, n) * Math.Pow(x, 2 * n + 1)) / Factorial(2 * n + 1);
        }

        return result;
    }
    static double CalculateCosine(double x, int terms)
    {
        double result = 0.0;

        for (int n = 0; n < terms; n++)
        {
            result += (Math.Pow(-1, n) * Math.Pow(x, 2 * n)) / Factorial(2 * n);
        }

        return result;
    }
    static long Factorial(int n)
    {
        if (n == 0 || n == 1)
            return 1;
        long result = 1;
        for (int i = 2; i <= n; i++)
        {
            result *= i;
        }
        return result;
    }
}
