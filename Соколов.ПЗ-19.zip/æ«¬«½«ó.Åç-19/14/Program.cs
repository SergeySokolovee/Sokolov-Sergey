﻿using System;

class Fibonacci
{
    static void Main()
    {
        double goldenRatio = (1 + Math.Sqrt(5)) / 2; 
        double tolerance = 1e-10; 
        int n1 = 1, n2 = 1; 
        int n = 2; 

        while (true)
        {
            int nextFibonacci = n1 + n2;
            n++;

            double ratio = (double)nextFibonacci / n2;

            if (Math.Abs(ratio - goldenRatio) < tolerance)
            {
                break;
            }

            n1 = n2; 
            n2 = nextFibonacci;
        }

        Console.WriteLine($"N = {n}, F_N = {n2}, F_(N-1) = {n1}");
        Console.WriteLine($"Отношение F_N / F_(N-1) = {n2 / (double)n1}");
        Console.WriteLine($"Золотое сечение ф = {goldenRatio}");
    }
}
