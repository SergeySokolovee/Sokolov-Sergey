﻿using System;

class CurrencyConverter
{
    static void Main()
    {
        const double usdToEur = 0.85; 
        const double usdToRub = 74.00; 
        const double eurToUsd = 1.18; 
        const double eurToRub = 87.00; 
        const double rubToUsd = 0.013; 
        const double rubToEur = 0.012; 

        Console.WriteLine("Добро пожаловать в конвертер валют!");
        Console.WriteLine("Доступные валюты: ");
        Console.WriteLine("1: USD (Доллары)");
        Console.WriteLine("2: EUR (Евро)");
        Console.WriteLine("3: RUB (Рубли)");

        Console.Write("Введите номер валюты, из которой хотите конвертировать: ");
        int fromCurrency = int.Parse(Console.ReadLine());

        Console.Write("Введите номер валюты, в которую хотите конвертировать: ");
        int toCurrency = int.Parse(Console.ReadLine());

        Console.Write("Введите сумму для конвертации: ");
        double amount = double.Parse(Console.ReadLine());

        double result = 0;

        switch (fromCurrency)
        {
            case 1:
                switch (toCurrency)
                {
                    case 2: 
                        result = amount * usdToEur;
                        break;
                    case 3: 
                        result = amount * usdToRub;
                        break;
                    default:
                        Console.WriteLine("Неверный выбор валюты для конвертации.");
                        return;
                }
                break;

            case 2: 
                switch (toCurrency)
                {
                    case 1: 
                        result = amount * eurToUsd;
                        break;
                    case 3: 
                        result = amount * eurToRub;
                        break;
                    default:
                        Console.WriteLine("Неверный выбор валюты для конвертации.");
                        return;
                }
                break;

            case 3: 
                switch (toCurrency)
                {
                    case 1: 
                        result = amount * rubToUsd;
                        break;
                    case 2: 
                        result = amount * rubToEur;
                        break;
                    default:
                        Console.WriteLine("Неверный выбор валюты для конвертации.");
                        return;
                }
                break;

            default:
                Console.WriteLine("Неверный выбор валюты для конвертации.");
                return;
        }
        Console.WriteLine($"Конвертированная сумма: {result} в выбранной валюте.");
    }
}
