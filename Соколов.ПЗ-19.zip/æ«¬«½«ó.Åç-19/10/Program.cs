﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите значение n (степень бинома): ");
        int n = int.Parse(Console.ReadLine());
        Console.Write("Введите значение a: ");
        double a = double.Parse(Console.ReadLine());

        Console.WriteLine($"Разложение бинома Ньютона (x + {a})^{n}:");
        for (int k = 0; k <= n; k++)
        {
            double coefficient = BinomialCoefficient(n, k);
            double aTerm = Math.Pow(a, n - k);

            if (k != 0)
            {
                Console.Write(" + ");
            }
            Console.Write($"{coefficient * aTerm}x^{k}");
        }
        Console.WriteLine();
    }

    static double BinomialCoefficient(int n, int k)
    {
        if (k > n) return 0;
        return Factorial(n) / (Factorial(k) * Factorial(n - k));
    }

    static double Factorial(int num)
    {
        if (num == 0 || num == 1)
            return 1;
        double result = 1;
        for (int i = 2; i <= num; i++)
        {
            result *= i;
        }
        return result;
    }
}

