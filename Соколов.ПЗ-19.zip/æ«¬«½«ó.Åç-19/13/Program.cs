﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите положительное целое число в шестнадцатеричной системе (например, A2F): ");
        string hexNumber = Console.ReadLine();

        try
        {
            int decimalNumber = Convert.ToInt32(hexNumber, 16);

            Console.WriteLine($"{hexNumber}(16) = {decimalNumber}(10)");
        }
        catch (FormatException)
        {
            Console.WriteLine("Ошибка: Введено некорректное шестнадцатеричное число.");
        }
        catch (OverflowException)
        {
            Console.WriteLine("Ошибка: Введенное число слишком велико для обработки.");
        }
    }
}
